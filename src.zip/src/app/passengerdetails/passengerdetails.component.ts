import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passengerdetails',
  templateUrl: './passengerdetails.component.html',
  styleUrls: ['./passengerdetails.component.css']
})
export class PassengerdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
